package br.furb.aula.poo.restaurantePolimorfico;

public class Cartao implements MetodoPagamento{

	private double saldo;
	
	
	
	public Cartao(double saldo) {
		setSaldo(saldo);
	}

	@Override
	public double calcularDesconto(Pedido pedido) {
		if(pedido == null) {
			throw new IllegalArgumentException("Pedido inválido");
		}
		
		double desconto = pedido.calcularValorPedido()*0.05;
		
		return desconto;
	}

	@Override
	public double calcularTroco(double valorPedido) {
		double suficiente = saldo - valorPedido;
		
		if(suficiente < 0) {
			throw new IllegalArgumentException("Saldo insuficiente");
		}
		return 0;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		if(saldo <= 0) {
			throw new IllegalArgumentException("Saldo invalido");
		}
		this.saldo = saldo;
	}
	
	
	

}
