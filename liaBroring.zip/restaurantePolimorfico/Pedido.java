package br.furb.aula.poo.restaurantePolimorfico;

import java.util.ArrayList;

public class Pedido {
	
	private ArrayList<Prato> pratos = new ArrayList<>();
	
	public double calcularValorPedido() {
		double soma=0;
		
		for(Prato p: pratos) {
			soma += p.getValor();
		}
		
		return soma;
	}
	
	public void incluirPrato(Prato prato) {
		if(prato==null) {
			throw new IllegalArgumentException("Prato invalido");
		}
		pratos.add(prato);
	}
	
	public void removerPrato(Prato prato) {
		if(prato==null) {
			throw new IllegalArgumentException("Prato invalido");
		}
	
		pratos.remove(prato);
	}

	public ArrayList<Prato> getPratos() {
		return pratos;
	}
	

}
