package br.furb.aula.poo.restaurantePolimorfico;

public class CartaoFidelidade extends Cartao{

	public CartaoFidelidade(double saldo) {
		super(saldo);
		
	}
	
	@Override
	public double calcularDesconto(Pedido pedido) {
		if(pedido == null) {
			throw new IllegalArgumentException("Pedido inválido");
		}
		
		double desconto = 0;
		
		for(Prato p: pedido.getPratos()) {
			if(p.getCategoria() == Categoria.SOBREMESA) {
				desconto += p.getValor();
			}
		}
		
		if(desconto == pedido.calcularValorPedido()) {
			desconto = pedido.calcularValorPedido()*0.30;
			
		}
		
		return desconto;
		
	}

}
