package br.furb.aula.poo.restaurantePolimorfico;

public class Dinheiro implements MetodoPagamento{
	
	private double valor;
	
	

	public Dinheiro(double valor) {
		setValor(valor);
	}

	@Override
	public double calcularDesconto(Pedido pedido) {
		
		if(pedido == null) {
			throw new IllegalArgumentException("Pedido inválido");
		}
		
		double desconto = pedido.calcularValorPedido()*0.10;
		
		return desconto;
	}

	@Override
	public double calcularTroco(double valorPedido) {
		double troco = valor - valorPedido;
		
		if(troco < 0) {
			throw new IllegalArgumentException("Valor insuficiente");
		}
		
		return troco;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		if(valor <= 0) {
			throw new IllegalArgumentException("Valor invalido");
		}
		this.valor = valor;
	}
	
	
	

}
