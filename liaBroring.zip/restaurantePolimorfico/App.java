package br.furb.aula.poo.restaurantePolimorfico;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
