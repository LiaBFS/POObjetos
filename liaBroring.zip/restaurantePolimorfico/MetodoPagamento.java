package br.furb.aula.poo.restaurantePolimorfico;

public interface MetodoPagamento {
	
	public double calcularDesconto(Pedido pedido);
	
	public double calcularTroco(double valorPedido);

}
